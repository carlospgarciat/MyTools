# AMI copy module.

Terraform module that makes copies of specific AMIs.

## Installation

Include the module in your root main.tf 
``` terraform
module "my_module"{
source = "https://github.com/carlospgarciat/ami-copy-module.git"
...
```


3. Initiate terraform **Terraform init**
4. **Plan** and **Apply** to your architecture

## Usage
Provide the needed parameters

```terraform
  ami_name = Ex. "amzn2-ami-hvm-2.0.20190508-x86_64-gp2"
  owner_id = 0 //Leave at 0 unless you wish to specify an actual Owner ID to fetch the AMI from.
  source_ami_region = Ex. "us-east-1"
  encrypt_ami = Boolean value to encrypt AMI copy
  kms_key_arn = specify key ARN to use for encryption
  descriptive_name = "Name tag value for easy recognition"
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)